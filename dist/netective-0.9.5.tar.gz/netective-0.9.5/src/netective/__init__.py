import netective.utils

# import netective.stats
import netective.structure
from .structure.structure import compare_structure
from .structure.structure import characterize_network
from .structure.structure import classify_networks

from .stats.stats import Benchmark
from .stats.stats import LinkEval
from .stats.stats import benchmarking


